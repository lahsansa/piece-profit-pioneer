import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Shield, Plus, ArrowRight } from "lucide-react";
import { toast } from "sonner";

interface UserStore {
  user_id: string;
  store_level: string;
  balance: number;
  total_topup: number;
  total_profit: number;
}

const Admin = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState<UserStore[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [txid, setTxid] = useState("");
  const [amount, setAmount] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    checkAdminAndLoad();
  }, []);

  const checkAdminAndLoad = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { navigate("/login"); return; }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id);

    const isAdmin = roles && roles.some((r: any) => r.role === "admin");
    if (!isAdmin) { navigate("/dashboard"); return; }

    await loadUsers();
  };

  const loadUsers = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("user_stores")
      .select("*");
    if (data) setUsers(data.map((u: any) => ({
      user_id: u.user_id,
      store_level: u.store_level,
      balance: Number(u.balance),
      total_topup: Number(u.total_topup),
      total_profit: Number(u.total_profit),
    })));
    setLoading(false);
  };

  const openTopupDialog = (userId: string) => {
    setSelectedUserId(userId);
    setTxid("");
    setAmount("");
    setDialogOpen(true);
  };

  const handleConfirmTopup = async () => {
    if (!txid.trim() || !amount.trim() || Number(amount) <= 0) {
      toast.error("أدخل معرف المعاملة والمبلغ");
      return;
    }
    setSubmitting(true);
    try {
      // Insert topup record
      const { error: topupError } = await supabase.from("topups").insert({
        user_id: selectedUserId,
        txid: txid.trim(),
        amount_usdt: Number(amount),
        status: "confirmed",
      });
      if (topupError) throw topupError;

      // Update user balance and total_topup
      const user = users.find(u => u.user_id === selectedUserId);
      if (user) {
        const { error: updateError } = await supabase
          .from("user_stores")
          .update({
            balance: user.balance + Number(amount),
            total_topup: user.total_topup + Number(amount),
          })
          .eq("user_id", selectedUserId);
        if (updateError) throw updateError;
      }

      toast.success("تم تأكيد الشحن بنجاح");
      setDialogOpen(false);
      await loadUsers();
    } catch (err: any) {
      toast.error(err.message || "حدث خطأ");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <div className="bg-destructive text-destructive-foreground px-4 py-3 pt-16 text-center">
        <div className="flex items-center justify-center gap-2">
          <Shield className="w-5 h-5" />
          <p className="text-sm font-bold">لوحة تحكم المشرف</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-5 space-y-5">
        <Card className="shadow-md border-0">
          <CardHeader>
            <CardTitle className="text-lg">قائمة المستخدمين</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-center text-muted-foreground py-8">جاري التحميل...</p>
            ) : users.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">لا يوجد مستخدمين بعد</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>معرف المستخدم</TableHead>
                      <TableHead>مستوى المتجر</TableHead>
                      <TableHead>الرصيد</TableHead>
                      <TableHead>إجمالي الشحن</TableHead>
                      <TableHead>إجراء</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((u) => (
                      <TableRow key={u.user_id}>
                        <TableCell className="font-mono text-xs">{u.user_id.slice(0, 8)}...</TableCell>
                        <TableCell>{u.store_level}</TableCell>
                        <TableCell className="font-bold">{u.balance.toFixed(2)}</TableCell>
                        <TableCell>{u.total_topup.toFixed(2)}</TableCell>
                        <TableCell>
                          <Button size="sm" onClick={() => openTopupDialog(u.user_id)}>
                            <Plus className="w-4 h-4 mr-1" />
                            تأكيد شحن
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Topup confirmation dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>تأكيد شحن الرصيد</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label>معرف المعاملة (TxID)</Label>
              <Input
                value={txid}
                onChange={(e) => setTxid(e.target.value)}
                placeholder="أدخل TxID"
                dir="ltr"
              />
            </div>
            <div>
              <Label>المبلغ (USDT)</Label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                dir="ltr"
                min="0"
                step="0.01"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleConfirmTopup} disabled={submitting} className="w-full">
              {submitting ? "جاري التأكيد..." : "تأكيد الشحن"}
              <ArrowRight className="w-4 h-4 mr-1" />
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Admin;
