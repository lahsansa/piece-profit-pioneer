import { motion } from "framer-motion";
import { useLang } from "@/hooks/use-lang";
import { Gem, Store } from "lucide-react";

const storePlans = [
  {
    name: "Small shop",
    nameAr: "متجر صغير",
    badge: "orange" as const,
    icon: Store,
    products: 5,
    commission: "10%",
    days: "Buyout",
    daysAr: "شراء",
    daily: "5.35~6.05",
    monthly: "160.50~181.50",
    annual: "1952.75~2208.25",
    price: 92,
    oldPrice: 230.00,
  },
  {
    name: "Medium shop",
    nameAr: "متجر متوسط",
    badge: "blue" as const,
    icon: Gem,
    products: 10,
    commission: "12%",
    days: "Buyout",
    daysAr: "شراء",
    daily: "14.70~16.70",
    monthly: "441.00~501.00",
    annual: "5365.50~6095.50",
    price: 248,
    oldPrice: 620.00,
  },
];


const StoreLevels = () => {
  const { lang } = useLang();
  const isAr = lang === "ar";

  return (
    <div className="min-h-screen bg-[#f5f7fa] pt-16 pb-24">
      {/* Header */}
      <div className="bg-[#2563eb] text-white py-4 px-4 text-center">
        <h1 className="text-lg font-semibold">{isAr ? "مستوى المتجر" : "Store level"}</h1>
      </div>

      {/* Cards */}
      <div className="px-4 py-5 space-y-5 max-w-md mx-auto">
        {storePlans.map((plan, i) => (
          <motion.div
            key={plan.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.15, duration: 0.4 }}
            className="bg-white rounded-2xl shadow-[0_2px_16px_rgba(0,0,0,0.08)] overflow-hidden"
          >
            {/* Title row */}
            <div className="flex items-center gap-2.5 px-4 pt-4 pb-2">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                  plan.badge === "orange"
                    ? "bg-orange-100 text-orange-500"
                    : "bg-blue-100 text-blue-500"
                }`}
              >
                <plan.icon className="w-5 h-5" />
              </div>
              <span className="font-semibold text-[15px] text-gray-800">
                {isAr ? plan.nameAr : plan.name}
              </span>
              <span
                className={`ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full text-white ${
                  plan.badge === "orange" ? "bg-orange-400" : "bg-blue-500"
                }`}
              >
                {plan.badge === "orange" ? "LV1" : "LV2"}
              </span>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-3 text-center px-4 py-3 border-y border-gray-100">
              {[
                { h: isAr ? "عدد المنتجات" : "Number of Products", v: plan.products },
                { h: isAr ? "عمولة المنتج" : "Product commission", v: plan.commission },
                { h: isAr ? "الأيام المتاحة" : "Available days", v: isAr ? plan.daysAr : plan.days },
              ].map((col) => (
                <div key={col.h}>
                  <p className="text-[10px] text-gray-400 leading-tight mb-1">{col.h}</p>
                  <p className="text-sm font-bold text-gray-800">{col.v}</p>
                </div>
              ))}
            </div>

            {/* Income box */}
            <div className="mx-4 my-3 bg-[#f8f9fb] rounded-xl p-3 space-y-2">
              {[
                { label: isAr ? "الدخل اليومي" : "Daily income", value: plan.daily },
                { label: isAr ? "الدخل الشهري" : "Monthly income", value: plan.monthly },
                { label: isAr ? "الدخل السنوي" : "Annual income", value: plan.annual },
              ].map((row) => (
                <div key={row.label} className="flex items-center justify-between">
                  <span className="text-[12px] text-gray-500">{row.label}</span>
                  <span className="text-[13px] font-semibold text-emerald-500">{row.value}</span>
                </div>
              ))}
            </div>

            {/* Price + Button */}
            <div className="px-4 pb-4 pt-1">
              <div className="flex items-baseline gap-2 mb-3">
                <span className="text-2xl font-bold text-gray-900">${plan.price}</span>
                <span className="text-sm text-gray-400 line-through">${plan.oldPrice.toFixed(2)}</span>
              </div>
              <button className="w-full py-3 rounded-xl bg-[#2563eb] hover:bg-[#1d4ed8] active:scale-[0.98] transition-all text-white font-semibold text-[15px] shadow-[0_4px_14px_rgba(37,99,235,0.35)]">
                {isAr ? "فعّل الآن" : "Activate now"}
              </button>
            </div>
          </motion.div>
        ))}
      </div>

    </div>
  );
};

export default StoreLevels;
