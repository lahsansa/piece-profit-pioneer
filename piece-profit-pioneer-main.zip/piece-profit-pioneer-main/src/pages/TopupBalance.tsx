import { motion } from "framer-motion";
import { Copy, AlertTriangle, MessageCircle, Check } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import Footer from "@/components/Footer";

const WALLET_ADDRESS = "TXrZ9BGi7H5kkGJN6u5rL4rDPxu7A1CxQN";

const steps = [
  "افتح محفظتك (Binance, Trust Wallet, TronLink...)",
  "اختر USDT وشبكة TRC20",
  "الصق عنوان المحفظة أو امسح QR Code",
  "أرسل المبلغ الذي تريده",
  "بعد التأكيد، أرسل لنا إثبات التحويل (Transaction ID أو لقطة شاشة) عبر WhatsApp أو الدعم",
];

const notes = [
  "سيتم إضافة الرصيد يدوياً خلال 30 دقيقة إلى 2 ساعات بعد التحقق",
  "لا ترسل أي عملة أخرى غير USDT",
  "جميع التحويلات نهائية وغير قابلة للاسترجاع",
];

const TopupBalance = () => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(WALLET_ADDRESS);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background pb-28" dir="rtl">
      <div className="max-w-md mx-auto px-4 py-6 space-y-5">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <h1 className="text-2xl font-bold text-foreground">شحن الرصيد</h1>
          <p className="text-lg text-muted-foreground mt-1">شحن رصيد حسابك بـ USDT</p>
        </motion.div>

        {/* Warning */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Alert className="border-destructive/50 bg-destructive/10">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <AlertDescription className="text-sm text-destructive font-medium space-y-1.5 mr-2">
              <p>⚠️ أرسل فقط USDT على شبكة TRC20 (موصى بها) أو ERC20</p>
              <p>⚠️ إذا أرسلت على شبكة خاطئة قد تفقد أموالك</p>
              <p>⚠️ الحد الأدنى للشحن: 10 USDT</p>
            </AlertDescription>
          </Alert>
        </motion.div>

        {/* Wallet Address */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="border-primary/20">
            <CardContent className="p-5 space-y-4">
              <p className="text-base font-semibold text-foreground text-center">عنوان المحفظة الخاص بنا:</p>

              {/* QR Code */}
              <div className="flex justify-center">
                <div className="bg-white p-3 rounded-xl shadow-sm">
                  <QRCodeSVG value={WALLET_ADDRESS} size={180} level="H" />
                </div>
              </div>

              {/* Address box */}
              <div
                onClick={handleCopy}
                className="bg-muted rounded-xl p-4 text-center cursor-pointer border-2 border-dashed border-primary/30 hover:border-primary/60 transition-colors"
              >
                <p className="text-xs text-muted-foreground mb-1">اضغط للنسخ</p>
                <p className="text-sm font-mono font-semibold text-foreground break-all leading-relaxed">
                  {WALLET_ADDRESS}
                </p>
              </div>

              {/* Copy button */}
              <Button
                onClick={handleCopy}
                className="w-full h-12 text-base font-bold gap-2"
                variant={copied ? "secondary" : "default"}
              >
                {copied ? (
                  <>
                    <Check className="w-5 h-5" />
                    تم النسخ!
                  </>
                ) : (
                  <>
                    <Copy className="w-5 h-5" />
                    نسخ العنوان
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Steps */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card>
            <CardContent className="p-5">
              <h2 className="text-lg font-bold text-foreground mb-4">خطوات الشحن</h2>
              <div className="space-y-3">
                {steps.map((step, i) => (
                  <div key={i} className="flex gap-3 items-start">
                    <span className="flex-shrink-0 w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                      {i + 1}
                    </span>
                    <p className="text-sm text-foreground leading-relaxed pt-0.5">{step}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Notes */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="bg-muted/50">
            <CardContent className="p-5">
              <h2 className="text-lg font-bold text-foreground mb-3">ملاحظات مهمة</h2>
              <ul className="space-y-2">
                {notes.map((note, i) => (
                  <li key={i} className="flex gap-2 items-start text-sm text-muted-foreground">
                    <span className="text-primary mt-0.5">•</span>
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        {/* Support CTA */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <a href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
            <Button className="w-full h-14 text-base font-bold gap-2 bg-emerald-600 hover:bg-emerald-700 text-white">
              <MessageCircle className="w-5 h-5" />
              لدي إثبات التحويل → تواصل مع الدعم
            </Button>
          </a>
        </motion.div>
      </div>
      <Footer />
    </div>
  );
};

export default TopupBalance;
